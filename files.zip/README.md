# 金融早报自动推送 — 部署指南

零基础也能跑起来，按顺序做完大约 15 分钟。

---

## 第一步：准备企业微信群机器人

1. 打开任意一个企业微信群（或新建一个专用群）
2. 点击右上角 **"..."** → **添加群机器人** → **新创建一个机器人**
3. 给机器人起个名字，比如「早报助手」
4. 创建完成后，复制 **Webhook 地址**，格式类似：
   ```
   https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   ```
5. 把这个地址先保存好，后面要用。

---

## 第二步：获取 Anthropic API Key

1. 打开 https://console.anthropic.com
2. 登录后点击左侧 **API Keys** → **Create Key**
3. 复制生成的 key（格式：`sk-ant-...`），保存好，**只显示一次**

---

## 第三步：创建 GitHub 仓库并上传代码

1. 登录 https://github.com，点击右上角 **+** → **New repository**
2. 仓库名随便取，比如 `morning-brief`，设为 **Private（私有）**，点击创建
3. 上传三个文件（点击 **Add file** → **Upload files**）：
   - `fetcher.py`
   - `brief_generator.py`
   - `daily_brief.yml` → **注意**：这个文件要放在 `.github/workflows/` 目录下
     
     放置方法：在仓库里先新建文件，路径输入 `.github/workflows/daily_brief.yml`，然后粘贴内容保存。

---

## 第四步：配置密钥（Secrets）

**这一步很重要**：API key 和 Webhook 地址不能直接写在代码里，要存到 GitHub 的加密保险箱。

1. 在你的仓库页面，点击 **Settings**（顶部菜单栏）
2. 左侧找 **Secrets and variables** → **Actions**
3. 点击 **New repository secret**，添加两个密钥：

   | Name | Value |
   |------|-------|
   | `ANTHROPIC_API_KEY` | 你的 `sk-ant-...` key |
   | `WECOM_WEBHOOK_URL` | 企业微信的 webhook 地址 |

---

## 第五步：手动测试一次

1. 在仓库页面点击 **Actions**（顶部菜单）
2. 左侧找 **每日金融早报**
3. 点击右侧 **Run workflow** → **Run workflow**
4. 等 1~2 分钟，查看运行日志
5. 去企业微信群看有没有收到早报消息

---

## 运行时间

每个工作日（周一至周五）北京时间 **08:30** 自动运行。

如需修改时间，编辑 `daily_brief.yml` 里的 cron 表达式：
```yaml
- cron: "30 0 * * 1-5"   # UTC 时间，北京时间 = UTC + 8
```
比如改成北京时间 09:00：`"0 1 * * 1-5"`

---

## 修改自选股

打开 `fetcher.py`，找到这一段：

```python
WATCHLIST = [
    {"name": "赣锋锂业", "code": "002460"},
    {"name": "兴德盛",   "code": "603344"},
    {"name": "天健科技", "code": "002888"},
]
```

按格式增减即可。沪市股票代码以 `6` 开头，深市以 `0` 或 `3` 开头。

---

## 常见问题

**Q：Actions 运行成功但没收到消息？**  
检查 WECOM_WEBHOOK_URL 是否正确，Webhook 地址过期需要在企业微信重新获取。

**Q：持仓数据显示"获取失败"？**  
天天基金偶尔会反爬，可以手动触发一次看看，一般隔天就好。季报披露本身就有 1-2 个月滞后，这是正常的。

**Q：想加港股/美股自选股？**  
告诉 Claude，可以扩展 `fetcher.py` 增加对应行情接口。
